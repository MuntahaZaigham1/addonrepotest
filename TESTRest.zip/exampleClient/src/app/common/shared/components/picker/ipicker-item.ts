export interface IPickerItem {
  id: number;
  name: string;
  createdDate?: string;
  updatedDate?: string;
  userId?: number;
}
