export { DummyListComponent } from './dummy-list.component';
export { DummyDetailsComponent } from './dummy-details.component';
export { DummyNewComponent } from './dummy-new.component';

export { IDummy } from './idummy';
export { DummyService, ParentService } from './dummy.service';
